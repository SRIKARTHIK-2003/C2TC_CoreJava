/**
 * 
 */
/**
 * 
 */
module jdbcMysQldemo {
	requires java.sql;
}